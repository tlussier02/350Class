Trevor Lussier
2445730
 tlussier@chapman.edu
CPSC350-04
PA3: Dd you see what i see?

A list of all source files submitted for the assignment
Monostack.h.
SpeakerView.h
SpeakerView.cpp
main.cpp
input.txt
ReadMe.md


A description of any known compile or runtime errors, code limitations, or deviations from the assignment specification (if applicable)


A list of all references used to complete the assignment, including peers (if applicable)
github copilot (commented where used) also helped for error handling, Authors: Trevor 


Instructions for running the assignment. (Typically applicable in advanced courses using build systems or third-party libraries) for us, it would be something like this:
g++ -std=c++11 main.cpp SpeakerView.cpp -o do_you_see
./do_you_see input.txt


                                        

