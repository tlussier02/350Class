Mari Muramoto and Trevor Lussier
002444483 and 
mmuramoto@chapman.edu and tlussier@chapman.edu
CPSC350-01/04
PA2: Not so Super Mario Bros

A list of all source files submitted for the assignment
Game.cpp
Game.h
Logger.cpp
Logger.h
main.cpp
Mario.cpp
Mario.h
World.cpp
World.h

A description of any known compile or runtime errors, code limitations, or deviations from the assignment specification (if applicable)


A list of all references used to complete the assignment, including peers (if applicable)
github copilot (commented where used) also helped for error handling, Authors: Mari and Trevor 


Instructions for running the assignment. (Typically applicable in advanced courses using build systems or third-party libraries) for us, it would be something like this:
To compile: g++ -std=c++11 main.cpp Game.cpp World.cpp Mario.cpp Logger.cpp -o Game
./Game config.txt gameLog.txt
To run: ./Game config.txt gameLog.txt                                             

